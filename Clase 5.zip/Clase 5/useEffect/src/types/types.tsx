export type FoodData = {
    category: string,
    desc: string,
    id: number,
    img: string,
    price: number,
    title: string
}