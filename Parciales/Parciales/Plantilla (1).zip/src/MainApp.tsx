//tsrafce
import React from 'react'

type Props = {}

const MainApp = (props: Props) => {
  return (
    <>
        <h1>MiAppMain</h1>
    </>
  )
}

export default MainApp