

type Props = {
    titulo:string,
    texto:string
}

const TextoDerecha = (_props: Props) => {
  return (
    <div>
        <h2>Texto Derecha</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cumque eveniet dolorum corporis blanditiis, officia corrupti similique exercitationem vel porro at perferendis delectus quibusdam beatae sequi neque nostrum, iure cupiditate repellat
        sit amet consectetur adipisicing elit. Cumque eveniet dolorum corporis blanditiis, officia corrupti similique exercitationem vel porro at perferendis delectus quibusdam beatae sequi neque nostrum, iure cupiditate repellasit amet consectetur</p>
    </div>
  )
}

export default TextoDerecha