import TituYForm from "./assets/Createletter"


type Props = {}

function Tarea4React({}: Props) {
  return (
    <>
        <TituYForm/>
    </>
  )
}

export default Tarea4React